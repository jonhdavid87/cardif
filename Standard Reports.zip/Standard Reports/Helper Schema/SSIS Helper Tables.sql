USE [SSISDB]
GO

/****** Object:  Schema [helper]    Script Date: 10/25/2013 9:09:22 AM ******/
CREATE SCHEMA [helper]
GO

GRANT SELECT ON SCHEMA::[helper] TO [public] AS [dbo]
GO

/****** Object:  Table [helper].[MessageType]    Script Date: 10/25/2013 9:02:43 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [helper].[MessageType](
	[Value] [smallint] NOT NULL,
	[Description] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
 CONSTRAINT [PK_MessageType] PRIMARY KEY CLUSTERED 
(
	[Value] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

/****** Object:  Table [helper].[ObjectType]    Script Date: 10/25/2013 9:02:43 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [helper].[ObjectType](
	[Value] [smallint] NOT NULL,
	[Description] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
 CONSTRAINT [PK_ObjectType] PRIMARY KEY CLUSTERED 
(
	[Value] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

/****** Object:  Table [helper].[OperationStatus]    Script Date: 10/25/2013 9:02:43 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [helper].[OperationStatus](
	[Status] [int] NOT NULL,
	[Description] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Category] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
 CONSTRAINT [PK_OperationStatus] PRIMARY KEY CLUSTERED 
(
	[Status] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

/****** Object:  Table [helper].[OperationType]    Script Date: 10/25/2013 9:02:43 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [helper].[OperationType](
	[Value] [smallint] NOT NULL,
	[Description] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
 CONSTRAINT [PK_OperationType] PRIMARY KEY CLUSTERED 
(
	[Value] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

/****** Object:  Table [helper].[EnvirnmentScope]    Script Date: 10/25/2013 9:02:43 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [helper].[EnvirnmentScope](
	[Value] [char](1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[Description] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
 CONSTRAINT [PK_EnvirnmentScope] PRIMARY KEY CLUSTERED 
(
	[Value] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

/****** Object:  Table [helper].[ValidateType]    Script Date: 10/25/2013 9:02:43 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [helper].[ValidateType](
	[Value] [char](1) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[Description] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
 CONSTRAINT [PK_ValidateType] PRIMARY KEY CLUSTERED 
(
	[Value] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

/****** Object:  Table [helper].[ContextType]    Script Date: 10/25/2013 9:02:43 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [helper].[ContextType](
	[Value] [smallint] NOT NULL,
	[Description] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
 CONSTRAINT [PK_ContextType] PRIMARY KEY CLUSTERED 
(
	[Value] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

/****** Object:  Table [helper].[MessageSourceType]    Script Date: 10/25/2013 9:02:43 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [helper].[MessageSourceType](
	[Value] [smallint] NOT NULL,
	[Description] [nvarchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
 CONSTRAINT [PK_MessageSourceType] PRIMARY KEY CLUSTERED 
(
	[Value] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

USE [SSISDB];
SET NOCOUNT ON;
SET XACT_ABORT ON;
GO

BEGIN TRANSACTION;
INSERT INTO [helper].[ContextType]([Value], [Description])
SELECT 10, N'Task' UNION ALL
SELECT 20, N'Pipeline' UNION ALL
SELECT 30, N'Sequence' UNION ALL
SELECT 40, N'For Loop' UNION ALL
SELECT 50, N'Foreach Loop' UNION ALL
SELECT 60, N'Package' UNION ALL
SELECT 70, N'Variable' UNION ALL
SELECT 80, N'Connection manager'
COMMIT;
RAISERROR (N'[helper].[ContextType]: Insert Batch: 1.....Done!', 10, 1) WITH NOWAIT;
GO

USE [SSISDB];
SET NOCOUNT ON;
SET XACT_ABORT ON;
GO

BEGIN TRANSACTION;
INSERT INTO [helper].[ObjectType]([Value], [Description])
SELECT 10, N'Folder' UNION ALL
SELECT 20, N'Project' UNION ALL
SELECT 30, N'Package' UNION ALL
SELECT 40, N'Environment' UNION ALL
SELECT 50, N'Instance of Execution'
COMMIT;
RAISERROR (N'[helper].[ObjectType]: Insert Batch: 1.....Done!', 10, 1) WITH NOWAIT;
GO

USE [SSISDB];
SET NOCOUNT ON;
SET XACT_ABORT ON;
GO

BEGIN TRANSACTION;
INSERT INTO [helper].[OperationStatus]([Status], [Description], [Category])
SELECT 1, N'Created', N'Other' UNION ALL
SELECT 2, N'Running', N'Running' UNION ALL
SELECT 3, N'Canceled', N'Other' UNION ALL
SELECT 4, N'Failed', N'Failed' UNION ALL
SELECT 5, N'Pending', N'Other' UNION ALL
SELECT 6, N'Ended Unexpectedly', N'Other' UNION ALL
SELECT 7, N'Succeeded', N'Succeeded' UNION ALL
SELECT 8, N'Stopping', N'Other' UNION ALL
SELECT 9, N'Completed', N'Other'
COMMIT;
RAISERROR (N'[helper].[OperationStatus]: Insert Batch: 1.....Done!', 10, 1) WITH NOWAIT;
GO

USE [SSISDB];
SET NOCOUNT ON;
SET XACT_ABORT ON;
GO

BEGIN TRANSACTION;
INSERT INTO [helper].[OperationType]([Value], [Description])
SELECT 1, N'Integration Services initialization' UNION ALL
SELECT 2, N'Retention Window Job Step' UNION ALL
SELECT 3, N'MaxProjectVersion' UNION ALL
SELECT 101, N'Project Deployment' UNION ALL
SELECT 106, N'Porject Restore' UNION ALL
SELECT 200, N'Package Execution' UNION ALL
SELECT 202, N'Stop Operation' UNION ALL
SELECT 300, N'Validate Project' UNION ALL
SELECT 301, N'Validate Package' UNION ALL
SELECT 1000, N'Configure Catalog'
COMMIT;
RAISERROR (N'[helper].[OperationType]: Insert Batch: 1.....Done!', 10, 1) WITH NOWAIT;
GO

USE [SSISDB];
SET NOCOUNT ON;
SET XACT_ABORT ON;
GO

BEGIN TRANSACTION;
INSERT INTO [helper].[EnvirnmentScope]([Value], [Description])
SELECT N'A', N'All environment references associated with the project' UNION ALL
SELECT N'D', N'No environment' UNION ALL
SELECT N'S', N'Single environment'
COMMIT;
RAISERROR (N'[helper].[EnvirnmentScope]: Insert Batch: 1.....Done!', 10, 1) WITH NOWAIT;
GO

USE [SSISDB];
SET NOCOUNT ON;
SET XACT_ABORT ON;
GO

BEGIN TRANSACTION;
INSERT INTO [helper].[ValidateType]([Value], [Description])
SELECT N'D', N'Dependency validation' UNION ALL
SELECT N'F', N'Full Validation'
COMMIT;
RAISERROR (N'[helper].[ValidateType]: Insert Batch: 1.....Done!', 10, 1) WITH NOWAIT;
GO

USE [SSISDB];
SET NOCOUNT ON;
SET XACT_ABORT ON;
GO

BEGIN TRANSACTION;
INSERT INTO [helper].[ContextType]([Value], [Description])
SELECT 10, N'Task' UNION ALL
SELECT 20, N'Pipeline' UNION ALL
SELECT 30, N'Sequence' UNION ALL
SELECT 40, N'For Loop' UNION ALL
SELECT 50, N'Foreach Loop' UNION ALL
SELECT 60, N'Package' UNION ALL
SELECT 70, N'Variable' UNION ALL
SELECT 80, N'Connection manager'
COMMIT;
RAISERROR (N'[helper].[ContextType]: Insert Batch: 1.....Done!', 10, 1) WITH NOWAIT;
GO

USE [SSISDB];
SET NOCOUNT ON;
SET XACT_ABORT ON;
GO

BEGIN TRANSACTION;
INSERT INTO [helper].[MessageSourceType]([Value], [Description])
SELECT 10, N'Entry APIs, such as T-SQL and CLR Stored procedures' UNION ALL
SELECT 20, N'External process used to run package (ISServerExec.exe)' UNION ALL
SELECT 30, N'Package-level objects' UNION ALL
SELECT 40, N'Control Flow tasks' UNION ALL
SELECT 50, N'Control Flow containers' UNION ALL
SELECT 60, N'Data Flow task'
COMMIT;
RAISERROR (N'[helper].[MessageSourceType]: Insert Batch: 1.....Done!', 10, 1) WITH NOWAIT;
GO


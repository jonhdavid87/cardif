﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ServiceManager.API
{
    public class Response
    {
        public string PNREF { get; set; }

        public bool IsSucess { get; set; }
        public string Message { get; set; }
    }
}
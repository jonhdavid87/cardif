﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace ServiceManager.API.Controllers
{
    public class ProcessManagerController : ApiController
    {
        [HttpGet]
        public Response ProcessData(decimal amount, long transactionID)
        {
            Response response = new Response();
            try
            {

                //TODO business logic

                response.PNREF = "PNREF-" + transactionID;
                response.IsSucess = true;
                response.Message = "Your transaction has been processed successfully.";

            }
            catch (Exception ex)
            {
                response.IsSucess = true;
                response.Message = ex.Message;

            }
            return response;

        }

    }
}
